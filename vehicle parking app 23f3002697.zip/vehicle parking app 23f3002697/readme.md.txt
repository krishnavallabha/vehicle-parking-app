Steps to Run the Vehicle Parking App

1. Create a virtual environment :

python -m venv .venv


2. Activate the virtual environment

On Windows:

.venv\Scripts\activate

On macOS/Linux:

source .venv/bin/activate



3. Install the required dependencies

pip install -r requirements.txt


4. Run the application

python Slotlyapp.py